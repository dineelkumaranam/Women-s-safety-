const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = 3000;
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "requests.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, "[]");

app.use(express.json({ limit: "50kb" }));
app.use(express.static(path.join(__dirname, "public")));

function readRequests() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return []; }
}

function saveRequests(requests) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(requests, null, 2));
}

function clean(value, max = 200) {
  return String(value ?? "").trim().slice(0, max);
}

app.get("/api/requests", (req, res) => {
  res.json(readRequests());
});

app.post("/api/requests", (req, res) => {
  const body = req.body || {};
  const required = ["studentName", "studentId", "phone", "pickupLocation", "destination", "requestTime"];

  for (const field of required) {
    if (!clean(body[field])) {
      return res.status(400).json({ message: `${field} is required.` });
    }
  }

  const requests = readRequests();

  const item = {
    id: crypto.randomUUID(),
    studentName: clean(body.studentName, 100),
    studentId: clean(body.studentId, 50),
    phone: clean(body.phone, 30),
    pickupLocation: clean(body.pickupLocation, 250),
    destination: clean(body.destination, 250),
    requestTime: clean(body.requestTime, 40),
    latitude: body.latitude === null || body.latitude === "" ? null : Number(body.latitude),
    longitude: body.longitude === null || body.longitude === "" ? null : Number(body.longitude),
    submittedAt: new Date().toISOString(),
    status: "Pending"
  };

  requests.unshift(item);
  saveRequests(requests);
  res.status(201).json(item);
});

app.patch("/api/requests/:id", (req, res) => {
  const allowed = ["Pending", "Accepted", "Escort Assigned", "Completed", "Cancelled"];
  const status = clean(req.body?.status, 30);

  if (!allowed.includes(status)) {
    return res.status(400).json({ message: "Invalid status." });
  }

  const requests = readRequests();
  const item = requests.find(r => r.id === req.params.id);

  if (!item) return res.status(404).json({ message: "Request not found." });

  item.status = status;
  item.updatedAt = new Date().toISOString();
  saveRequests(requests);
  res.json(item);
});

app.listen(PORT, () => {
  console.log(`Campus Escort System running at http://localhost:${PORT}`);
});
