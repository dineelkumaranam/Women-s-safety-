const form = document.getElementById("escortForm");
const message = document.getElementById("message");
const locationBtn = document.getElementById("locationBtn");
const locationStatus = document.getElementById("locationStatus");

locationBtn.addEventListener("click", () => {
  if (!navigator.geolocation) {
    locationStatus.textContent = "Geolocation is not supported by this browser.";
    return;
  }

  locationStatus.textContent = "Requesting your location permission...";
  navigator.geolocation.getCurrentPosition(
    position => {
      document.getElementById("latitude").value = position.coords.latitude.toFixed(6);
      document.getElementById("longitude").value = position.coords.longitude.toFixed(6);
      const lat = position.coords.latitude.toFixed(5);
      const lon = position.coords.longitude.toFixed(5);
      document.getElementById("pickupLocation").value =
        `Current GPS location (${lat}, ${lon})`;
      locationStatus.textContent = "Current location captured. Please verify the pickup location.";
    },
    () => {
      locationStatus.textContent = "Location permission was unavailable. You can type the pickup location manually.";
    },
    { enableHighAccuracy: true, timeout: 10000 }
  );
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  message.textContent = "Submitting...";

  const payload = {
    studentName: document.getElementById("studentName").value,
    studentId: document.getElementById("studentId").value,
    phone: document.getElementById("phone").value,
    pickupLocation: document.getElementById("pickupLocation").value,
    destination: document.getElementById("destination").value,
    requestTime: document.getElementById("requestTime").value,
    latitude: document.getElementById("latitude").value,
    longitude: document.getElementById("longitude").value
  };

  try {
    const response = await fetch("/api/requests", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const result = await response.json();
    if (!response.ok) throw new Error(result.message || "Request failed");

    message.innerHTML = `<div class="success">
      <strong>Request submitted successfully.</strong><br>
      Request ID: ${result.id}<br>
      Status: ${result.status}
    </div>`;
    form.reset();
    locationStatus.textContent = "";
  } catch (error) {
    message.innerHTML = `<div class="error">${error.message}</div>`;
  }
});
