const express=require("express");
const fs=require("fs");
const path=require("path");
const crypto=require("crypto");

const app=express(),PORT=3000;
const DATA_DIR=path.join(__dirname,"data");
const DATA_FILE=path.join(DATA_DIR,"requests.json");
if(!fs.existsSync(DATA_DIR))fs.mkdirSync(DATA_DIR,{recursive:true});
if(!fs.existsSync(DATA_FILE))fs.writeFileSync(DATA_FILE,"[]");
app.use(express.json({limit:"50kb"}));
app.use(express.static(path.join(__dirname,"public")));

const read=()=>{try{return JSON.parse(fs.readFileSync(DATA_FILE,"utf8"))}catch{return[]}};
const save=x=>fs.writeFileSync(DATA_FILE,JSON.stringify(x,null,2));
const clean=(v,n=250)=>String(v??"").trim().slice(0,n);
const coord=v=>{
  if(v===null||v===undefined||v==="")return null;
  const n=Number(v); return Number.isFinite(n)?n:null;
};

app.get("/api/requests",(req,res)=>res.json(read()));

app.post("/api/requests",(req,res)=>{
  const b=req.body||{};
  for(const f of ["studentName","studentId","phone","pickupLocation","destination","requestTime"])
    if(!clean(b[f]))return res.status(400).json({message:`${f} is required.`});

  const item={
    id:crypto.randomUUID(),
    studentName:clean(b.studentName,100),
    studentId:clean(b.studentId,50),
    phone:clean(b.phone,30),
    pickupLocation:clean(b.pickupLocation),
    destination:clean(b.destination),
    requestTime:clean(b.requestTime,50),
    pickupLat:coord(b.pickupLat),
    pickupLng:coord(b.pickupLng),
    destinationLat:coord(b.destinationLat),
    destinationLng:coord(b.destinationLng),
    submittedAt:new Date().toISOString(),
    status:"Pending"
  };
  const requests=read();requests.unshift(item);save(requests);
  res.status(201).json(item);
});

app.patch("/api/requests/:id",(req,res)=>{
  const allowed=["Pending","Accepted","Escort Assigned","Completed","Cancelled"];
  const status=clean(req.body?.status,30);
  if(!allowed.includes(status))return res.status(400).json({message:"Invalid status."});
  const requests=read(),item=requests.find(r=>r.id===req.params.id);
  if(!item)return res.status(404).json({message:"Request not found."});
  item.status=status;item.updatedAt=new Date().toISOString();save(requests);res.json(item);
});

app.listen(PORT,()=>console.log(`CampusSafe GPS running at http://localhost:${PORT}`));
