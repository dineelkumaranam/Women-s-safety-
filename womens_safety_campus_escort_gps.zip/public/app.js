const form=document.getElementById("escortForm");
const message=document.getElementById("message");
const mapStatus=document.getElementById("mapStatus");
let selectionMode="pickup";
let pickupMarker=null;
let destinationMarker=null;

const map=L.map("map").setView([13.6288,79.4192],15); // default campus-style starting view
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{
  maxZoom:19,
  attribution:"© OpenStreetMap contributors"
}).addTo(map);

function setMode(mode){
  selectionMode=mode;
  mapStatus.textContent=mode==="pickup"
    ?"Pickup mode: tap the map where you want to be collected."
    :"Destination mode: tap the map where you want to be dropped.";
}
document.getElementById("pickupMode").onclick=()=>setMode("pickup");
document.getElementById("destinationMode").onclick=()=>setMode("destination");

function setPoint(lat,lng){
  const coords=`${lat.toFixed(6)}, ${lng.toFixed(6)}`;
  if(selectionMode==="pickup"){
    if(pickupMarker) map.removeLayer(pickupMarker);
    pickupMarker=L.marker([lat,lng]).addTo(map).bindPopup("Pickup location").openPopup();
    document.getElementById("pickupLat").value=lat;
    document.getElementById("pickupLng").value=lng;
    document.getElementById("pickupLocation").value=`GPS location (${coords})`;
    document.getElementById("pickupDisplay").textContent=coords;
  }else{
    if(destinationMarker) map.removeLayer(destinationMarker);
    destinationMarker=L.marker([lat,lng]).addTo(map).bindPopup("Destination").openPopup();
    document.getElementById("destinationLat").value=lat;
    document.getElementById("destinationLng").value=lng;
    document.getElementById("destination").value=`GPS location (${coords})`;
    document.getElementById("destinationDisplay").textContent=coords;
  }
}
map.on("click",e=>setPoint(e.latlng.lat,e.latlng.lng));

document.getElementById("gpsBtn").onclick=()=>{
  if(!navigator.geolocation){
    mapStatus.textContent="GPS is not supported by this browser.";
    return;
  }
  mapStatus.textContent="Requesting GPS permission...";
  navigator.geolocation.getCurrentPosition(pos=>{
    const lat=pos.coords.latitude,lng=pos.coords.longitude;
    map.setView([lat,lng],17);
    setMode("pickup");
    setPoint(lat,lng);
    mapStatus.textContent="GPS pickup location captured. Verify the marker before submitting.";
  },err=>{
    mapStatus.textContent="GPS permission/location unavailable. You can select the point manually.";
  },{enableHighAccuracy:true,timeout:10000});
};

form.addEventListener("submit",async e=>{
  e.preventDefault();
  message.textContent="Submitting...";
  const payload={
    studentName:document.getElementById("studentName").value,
    studentId:document.getElementById("studentId").value,
    phone:document.getElementById("phone").value,
    pickupLocation:document.getElementById("pickupLocation").value,
    destination:document.getElementById("destination").value,
    requestTime:document.getElementById("requestTime").value,
    pickupLat:document.getElementById("pickupLat").value,
    pickupLng:document.getElementById("pickupLng").value,
    destinationLat:document.getElementById("destinationLat").value,
    destinationLng:document.getElementById("destinationLng").value
  };
  try{
    const response=await fetch("/api/requests",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
    const result=await response.json();
    if(!response.ok)throw new Error(result.message||"Request failed");
    message.innerHTML=`<div class="success"><strong>Escort request submitted.</strong><br>Request ID: ${result.id}<br>Status: ${result.status}</div>`;
    form.reset();
    document.getElementById("pickupDisplay").textContent="Not selected";
    document.getElementById("destinationDisplay").textContent="Not selected";
    if(pickupMarker)map.removeLayer(pickupMarker);
    if(destinationMarker)map.removeLayer(destinationMarker);
    pickupMarker=destinationMarker=null;
  }catch(err){
    message.innerHTML=`<div class="error">${err.message}</div>`;
  }
});
